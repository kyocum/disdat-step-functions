# Infrastructure

aws: Scripts for working with AWS resources such as S3 and EC2

kickstart: Scripts for creating linux and python environments.  Used for
Docker images. 

pythia: Database for storing bundles, lineage, and schemas. 

kubernetes: Facilities for starting, stopping, resizing kubernetes
clusters. 

Dockerfiles: Set of scripts to create Docker images. 
