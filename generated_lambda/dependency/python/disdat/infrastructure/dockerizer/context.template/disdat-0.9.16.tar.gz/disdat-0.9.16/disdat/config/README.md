Config
======
Default configurations for users who do not have a disdat configuration